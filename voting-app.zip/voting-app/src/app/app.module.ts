import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DropdownComponent } from './dropdown/dropdown.component';
import { UsernameselectionComponent } from './usernameselection/usernameselection.component';
import { FormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { LinksComponent } from './links/links.component';
import { RouterModule } from '@angular/router';
import { CreatequestionsComponent } from './createquestions/createquestions.component';
import { ViewquestionsComponent } from './viewquestions/viewquestions.component';
import { ViewresultsComponent } from './viewresults/viewresults.component';
import { HttpClientModule } from '@angular/common/http';
import { VotingApiService } from './voting-api.service';
import {MatRadioModule} from '@angular/material/radio';
import { MatTableModule } from '@angular/material/table';
import { MatInputModule } from '@angular/material/input';
import { MatSortModule } from '@angular/material/sort';


@NgModule({
  declarations: [
    AppComponent,
    DropdownComponent,
    UsernameselectionComponent,
    LinksComponent,
    CreatequestionsComponent,
    ViewquestionsComponent,
    ViewresultsComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    BrowserAnimationsModule,
    MatFormFieldModule,
    MatSelectModule,
    HttpClientModule,
    MatRadioModule,
    MatTableModule,
    MatInputModule,
    MatSortModule,
    RouterModule.forRoot([
      { path: 'create-new-questions', component: CreatequestionsComponent },
      { path: 'view-questions-and-vote', component: ViewquestionsComponent },
      { path: 'view-results', component: ViewresultsComponent },
      { path: 'homepage', component: LinksComponent },
      
      { path: '**', redirectTo: '' }
    ])
  ],
  providers: [VotingApiService],
  bootstrap: [AppComponent]
})
export class AppModule { }
