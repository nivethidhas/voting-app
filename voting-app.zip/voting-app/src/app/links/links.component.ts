import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { VotingApiService } from '../voting-api.service';

@Component({
  selector: 'app-links',
  templateUrl: './links.component.html',
  styleUrls: ['./links.component.css'],
  providers:  [ VotingApiService ]
})
export class LinksComponent {
  selectedUser: string;
  data: any;

  constructor(private route: ActivatedRoute, private router: Router,private votingApiService: VotingApiService) { }

  ngOnInit() {
  }
  onUserSelected() {
    switch (this.selectedUser) {
      case 'link1':
       // this.router.navigate(['create-new-questions']);
        break;
      case 'link2':
      //  this.router.navigate(['view-questions-and-vote']);
        break;
      case 'link3':
      //  this.router.navigate(['view-results']);
        break;
      default:
        break;
    }
  }
}
