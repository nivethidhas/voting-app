import { Component } from '@angular/core';

import { MatTableDataSource } from '@angular/material/table';

export interface MyData {
  question: string;
  noofVotes: string;
  yesPercent: string;
  noPercent: string;
}

const DATA: MyData[] = [
  { question: 'Are you Employed?', noofVotes: '35', yesPercent: '10', noPercent:'90' },
  { question: 'Do you have drivers license?', noofVotes: '36', yesPercent: '40', noPercent:'60'  },
  { question: 'Are you a senior citizen?', noofVotes: '37', yesPercent: '20', noPercent:'80' },
];

@Component({
  selector: 'app-viewresults',
  templateUrl: './viewresults.component.html',
  styleUrls: ['./viewresults.component.css']
})
export class ViewresultsComponent {
  dataSource = new MatTableDataSource<MyData>(DATA);
  displayedColumns: string[] = ['Questions', 'No of Votes', 'Yes Percentage (%)', 'No Percentage (%)'];

}
