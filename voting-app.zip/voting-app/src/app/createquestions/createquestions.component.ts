import { Component,ViewChild} from '@angular/core';
import { NgForm } from '@angular/forms';
import { VotingApiService } from '../voting-api.service';

 

@Component({
  selector: 'app-createquestions',
  templateUrl: './createquestions.component.html',
  styleUrls: ['./createquestions.component.css']
})
export class CreatequestionsComponent {
  data: any;

  constructor(private votingApiService: VotingApiService) { }

  ngOnInit() {
    this.data = this.votingApiService.getData();
  }
 
  @ViewChild('myForm', { static: true })
  myForm!: NgForm;

  textAreaInput = '';
  existingTextAreaInputArr =["Do you have drivers license?","Are you 18 years old?","Are you registered to Vote?","Are you a senior citizen?","Are you Employed?"];

  

  //textAreaControl = new FormControl('', Validators.required);

  onSubmit(){
    if(this.textAreaInput.length<1){
  
    alert("Please fill in the mandatory field");
    }
    else if (this.textAreaInput.length>0){
      var newQuestion = true;
      if (this.existingTextAreaInputArr.length>0) {
        for(let i=0;i<this.existingTextAreaInputArr.length;i++){
          if(this.existingTextAreaInputArr[i]==(this.textAreaInput)) {
            alert("Already existing question, Please enter new question");
            newQuestion= false;
            break;
          }
        }
        if(newQuestion) {
          //call API to save the questions
          var createQuesReqBody = {
            "createQues" : this.textAreaInput,
            "username" : this.data
          }
      this.votingApiService.postCreateQuesData(createQuesReqBody).subscribe(response => {
        console.log("response"); 
      });
        }
      }
    }
  } 
}
