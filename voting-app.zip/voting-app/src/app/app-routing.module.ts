import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DropdownComponent } from './dropdown/dropdown.component';
import { LinksComponent } from './links/links.component';
import { VotingApiService } from './voting-api.service';

const routes: Routes = [
  { path: 'userselection', component: LinksComponent },
  { path: '', component: DropdownComponent }
];



@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers: [VotingApiService]
})
export class AppRoutingModule { }
