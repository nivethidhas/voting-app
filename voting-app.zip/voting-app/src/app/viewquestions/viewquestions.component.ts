import { Component } from '@angular/core';
import { VotingApiService } from '../voting-api.service';

@Component({
  selector: 'app-viewquestions',
  templateUrl: './viewquestions.component.html',
  styleUrls: ['./viewquestions.component.css']
})
export class ViewquestionsComponent {

  constructor(private votingApiService: VotingApiService) { }

 data : any;
  radioSelected :any;
  votingResponseBody :any [];
  questionsArray: any[]= [
  {name: 'Do you have drivers license?', valueYes :''},
  {name: 'Are you 18 years old?',  valueYes :''},
  {name: 'Are you registered to Vote?', valueYes :''},
  {name: 'Are you a senior citizen?', valueYes :''},
  {name: 'Are you Employed?', valueYes :''}
];

ngOnInit() {
  this.data = this.votingApiService.getData();
}

trackByIndex(index: number, obj: any): any {
  return index;
}

radioClick(value : any, radioSelected:any){
  let tempObj = {"question":value,
  "selection":radioSelected };
  console.log(value);
  console.log(radioSelected);
  if(this.questionsArray.length>0){
  for(let i=0;i<this.questionsArray.length;i++){
        if(this.questionsArray[i].name==tempObj.question){
          this.questionsArray[i].valueYes = tempObj.selection;
        }
  }
}
}

votingResponse(){
  this.votingApiService.postVoteQuesData(this.questionsArray, this.data).subscribe(response => {
    console.log("response"); 
  });
  }

}
