import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class VotingApiService {
  private apiUrl = 'https://www.google.com'; 
  constructor(private http: HttpClient) { }
  getSomeData(): Observable<any> {
    return this.http.get('/homepage');
  }
  postCreateQuesData(data: any) {
    return this.http.post(`${this.apiUrl}/my-endpoint`, data);
  }

  postVoteQuesData(data: any, username: any) {
  let responseBody= { "username": username,
  "data" : data
  };
    return this.http.post(`${this.apiUrl}/my-endpoint`, responseBody);
  }
  

   private data:any = undefined;

    setData(data:any){
        this.data = data;
    }

    getData():any{
        return this.data;
    } 

}
