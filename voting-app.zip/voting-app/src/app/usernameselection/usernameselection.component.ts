import { Component } from '@angular/core';
import { ActivatedRoute,Router } from '@angular/router';
import { VotingApiService } from '../voting-api.service';

@Component({
  selector: 'app-usernameselection',
  templateUrl: './usernameselection.component.html',
  styleUrls: ['./usernameselection.component.css']
})
export class UsernameselectionComponent {


  //data:any = {username: "example"};
 
    selectedUser: string;
  
   /* onUserSelected(event) {
      this.selectedUser = event.target.value;
    }*/

    constructor(private route: ActivatedRoute, private router: Router, private votingApiService:VotingApiService) { }


    onSelectedUser() {

    this.votingApiService.setData(this.selectedUser);
      switch (this.selectedUser) {
        case 'user1':
         // this.router.navigate(['check']);
          break;
        case 'user2':
         // this.router.navigate(['']);
          break;
        case 'user3':
         // this.router.navigate(['']);
          break;
        default:
          break;
      }
    }

}
