import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UsernameselectionComponent } from './usernameselection.component';


describe('UsernameselectionComponent', () => {
  let component: UsernameselectionComponent;
  let fixture: ComponentFixture<UsernameselectionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UsernameselectionComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UsernameselectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
