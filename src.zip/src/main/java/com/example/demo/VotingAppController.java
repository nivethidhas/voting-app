package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/votingapp")
public class VotingAppController {
	 @Autowired
	    private VotingAppRepository votingAppRepository;
	/* @Autowired
	    private CreateQuestionRepository createQuestionRepository;*/
	 
	/* @PostMapping
	    public ResponseEntity<CreateQuestion> createQuestion(@RequestBody CreateQuestion createquestion) {
		 CreateQuestion saveQuestion = createQuestionRepository.save(createquestion);
	        return new ResponseEntity<>(saveQuestion, HttpStatus.CREATED);
	    }*/

	    @GetMapping
	    public List<VotingAppBean> getAllEmployees() {
	        return votingAppRepository.findAll();
	    }
	    
	    

	    @GetMapping("/{id}")
	    public ResponseEntity<VotingAppBean> getEmployeeById(@PathVariable Long id) {
	        Optional<VotingAppBean> votingapp = votingAppRepository.findById(id);
	        if (votingapp.isPresent()) {
	            return new ResponseEntity<>(votingapp.get(), HttpStatus.OK);
	        } else {
	            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	        }
	    }

	    @PostMapping
	    public ResponseEntity<VotingAppBean> createEmployee(@RequestBody VotingAppBean votingapp) {
	    	VotingAppBean savedEmployee = votingAppRepository.save(votingapp);
	        return new ResponseEntity<>(savedEmployee, HttpStatus.CREATED);
	    }

	    @PutMapping("/{id}")
	    public ResponseEntity<VotingAppBean> updateEmployee(@PathVariable Long id, @RequestBody VotingAppBean votingapp) {
	        Optional<VotingAppBean> optionalEmployee = votingAppRepository.findById(id);
	        if (optionalEmployee.isPresent()) {
	        	votingapp.setId(id);
	        	VotingAppBean savedEmployee = votingAppRepository.save(votingapp);
	            return new ResponseEntity<>(savedEmployee, HttpStatus.OK);
	        } else {
	            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	        }
	    }

	    @DeleteMapping("/{id}")
	    public ResponseEntity<Void> deleteEmployee(@PathVariable Long id) {
	        Optional<VotingAppBean> optionalEmployee = votingAppRepository.findById(id);
	        if (optionalEmployee.isPresent()) {
	        	votingAppRepository.delete(optionalEmployee.get());
	            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	        } else {
	            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	        }
	    }
}
