
package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/createQuestions")
public class CreateQuestionController {
    @Autowired
    private CreateQuestionRepository createQuestionRepository;

  

    @PostMapping
    public ResponseEntity<CreateQuestion> createEmployee(@RequestBody CreateQuestion createquestion) {
        CreateQuestion saveQues = createQuestionRepository.save(createquestion);
        return new ResponseEntity<>(saveQues, HttpStatus.CREATED);
    }
    
    @GetMapping("/all")
    public List<CreateQuestion> getAllQuestions() {
        return createQuestionRepository.findAll();
    }

   

   
}
