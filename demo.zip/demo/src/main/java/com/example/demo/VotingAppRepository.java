package com.example.demo;

import org.springframework.data.jpa.repository.JpaRepository;

public interface VotingAppRepository extends JpaRepository<VotingAppBean, Long>{

}
