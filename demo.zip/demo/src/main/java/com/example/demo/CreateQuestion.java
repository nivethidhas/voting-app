package com.example.demo;

import java.sql.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class CreateQuestion {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id ;
	private Date timestamp;
	 public Date getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	private String createqestion;
    private String username;
    
    public String getCreateqestion() {
		return createqestion;
	}

	public void setCreateqestion(String createqestion) {
		this.createqestion = createqestion;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

}
